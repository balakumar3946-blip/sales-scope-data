package com.salesscope.dashboard

import android.annotation.SuppressLint
import android.app.Activity
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

private const val TAG = "SalesScope"

// Public, unauthenticated raw JSON files hosted in the user's own GitHub repo.
// These mirror the shape of the EMBEDDED_DATA snapshot bundled in the WebView asset.
private const val DATA_BASE_URL =
    "https://raw.githubusercontent.com/balakumar3946-blip/sales-scope-data/main/data"

private val DATA_FILES = mapOf(
    "regions" to "regions.json",
    "prospects" to "prospects.json",
    "distributorsApac" to "distributors-apac.json",
    "distributorsEu" to "distributors-eu.json",
    "distributorsMe" to "distributors-me.json",
    "distributorsNa" to "distributors-na.json",
    "boneZoneLeads" to "boneZoneLeads.json"
)

class MainActivity : Activity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (isOnline()) {
                    fetchAndApplyFreshData()
                }
            }
        }

        webView.loadUrl("file:///android_asset/dashboard.html")
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun fetchAndApplyFreshData() {
        CoroutineScope(Dispatchers.Main).launch {
            val merged = withContext(Dispatchers.IO) { fetchAllFiles() }
            if (merged != null) {
                // JSONObject.quote() produces a safely double-quoted, backslash-escaped
                // JSON string literal, which is also valid as a JS string literal.
                // U+2028/U+2029 are valid in JSON strings but illegal unescaped inside a
                // raw JS string literal, so escape those two separately.
                val jsLiteral = JSONObject.quote(merged.toString())
                    .replace(" ", "\\u2028")
                    .replace(" ", "\\u2029")
                webView.evaluateJavascript(
                    "window.applyFreshData && window.applyFreshData($jsLiteral);",
                    null
                )
            } else {
                Log.w(TAG, "Fresh data fetch failed; keeping bundled snapshot.")
            }
        }
    }

    /**
     * Fetches every data file and merges them into one object matching EMBEDDED_DATA's shape.
     *
     * All files in the repo (regions.json, prospects.json, distributors-*.json,
     * boneZoneLeads.json) are published as an id-keyed JSON object, e.g.
     * {"apac-1": {...}, "apac-2": {...}}. regionsData stays a dict; the other
     * collections need to become id-tagged arrays, matching what the bundled
     * dashboard.html expects (see EMBEDDED_DATA / loadDataset in the HTML).
     */
    private fun fetchAllFiles(): JSONObject? {
        return try {
            val regions = fetchJsonObject(DATA_FILES["regions"]!!) ?: return null
            val prospects = fetchJsonObject(DATA_FILES["prospects"]!!) ?: return null
            val boneZone = fetchJsonObject(DATA_FILES["boneZoneLeads"]!!) ?: return null

            val distributors = JSONObject()
            for (key in listOf("distributorsApac", "distributorsEu", "distributorsMe", "distributorsNa")) {
                val part = fetchJsonObject(DATA_FILES[key]!!) ?: continue
                val keys = part.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    distributors.put(k, part.get(k))
                }
            }

            JSONObject().apply {
                put("generatedAt", java.time.Instant.now().toString())
                put("regions", regions)
                put("prospects", dictToArrayWithId(prospects))
                put("tenders", JSONArray())
                put("distributors", dictToArrayWithId(distributors))
                put("boneZoneLeads", dictToArrayWithId(boneZone))
            }
        } catch (e: Exception) {
            Log.e(TAG, "fetchAllFiles failed", e)
            null
        }
    }

    /** Converts {"id1": {...}, "id2": {...}} into [{"id":"id1", ...}, {"id":"id2", ...}]. */
    private fun dictToArrayWithId(dict: JSONObject): JSONArray {
        val arr = JSONArray()
        val keys = dict.keys()
        while (keys.hasNext()) {
            val id = keys.next()
            val obj = JSONObject(dict.getJSONObject(id).toString())
            obj.put("id", id)
            arr.put(obj)
        }
        return arr
    }

    private fun fetchJsonObject(fileName: String): JSONObject? {
        val url = URL("$DATA_BASE_URL/$fileName")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 15_000
        conn.requestMethod = "GET"
        return try {
            if (conn.responseCode != HttpURLConnection.HTTP_OK) return null
            val text = conn.inputStream.bufferedReader().use(BufferedReader::readText)
            JSONObject(text)
        } catch (e: Exception) {
            Log.e(TAG, "fetchJsonObject failed for $fileName", e)
            null
        } finally {
            conn.disconnect()
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
